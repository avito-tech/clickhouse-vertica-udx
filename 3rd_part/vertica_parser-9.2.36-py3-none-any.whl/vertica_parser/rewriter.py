#!/usr/bin/python
# -*- coding: utf-8 -*-

import copy
import re
from collections import OrderedDict
from functools import partial

from vertica_parser import db_catalog
from vertica_parser.analyzer import InsertNode, CTASNode
from vertica_parser.analyzer import SelectNode, SimpleSelectNode
from vertica_parser.analyzer import PredicateNode, TableNode
from vertica_parser.analyzer import ExplainNode 
from vertica_parser.analyzer import list_cte, list_from, list_predicates


IDENT = r'([_a-z][_a-z0-9]*|"[^"]+")'
COLREF = r'({IDENT}|{IDENT}.{IDENT})'.format(IDENT=IDENT)


class ColSrc(object):
    def __init__(self, node=None, name=None, expr_path=None, alt=None):
        self.node = node
        self.name = name
        self.expr_path = expr_path or list()
        self.alternatives = alt or list()

    def wrap(self, expr):
        return ColSrc(self.node, self.name, [expr] + self.expr_path, self.alternatives)


def table_name(qualified_name):
    return qualified_name.lower()


def column_name(qualified_name):
    return qualified_name.rpartition('.')[2].strip('"').lower()


def column_rel(qualified_name):
    return qualified_name.rpartition('.')[0].strip('"').lower()


def rewrite_statement(query_node):
    out_cols = OrderedDict()

    if isinstance(query_node, SimpleSelectNode):
        cte_nodes = {table_name(cte.alias): cte.select_clause for cte in list_cte(query_node)}

        all_inputs = [i for c in query_node.column_list for i in c.input_columns]
        all_inputs += sum([p.input_columns for p in list_predicates(query_node)], [])

        # bind input relations
        from_tables = dict()
        for table in list_from(query_node):
            alias = table_name(table.alias or table.table_ref.rpartition('.')[2])

            if table.select_clause:
                from_tables[alias] = rewrite_statement(table.select_clause)
                continue

            table_n = table_name(table.table_ref)
            if table_n in cte_nodes:
                table.select_clause = copy.deepcopy(cte_nodes[table_n]) 
                table.table_ref = None
                table.alias = alias
                from_tables[alias] = rewrite_statement(table.select_clause)

            elif table_n in db_catalog.table_columns:
                from_tables[alias] = {c: [ColSrc(table, table_n + '.' + c)]
                                      for c in db_catalog.table_columns[table_n]}
            else:
                from_tables[alias] = {column_name(i): [ColSrc(table, table_n + '.' + column_name(i))]
                                      for i in all_inputs if column_rel(i) == alias}

        # pushdown predicates
        for p in list_predicates(query_node):
            pushdown_predicate(p, from_tables)

        # bind semijoins
        pred_elements = []
        pred_elements.append(query_node.where_clause or PredicateNode())
        while pred_elements:
            pred = pred_elements.pop(0)
            if pred.semijoin and isinstance(pred.semijoin, SelectNode):
                rewrite_statement(pred.semijoin)
            pred_elements.extend(pred.elements)

        # bind output columns
        for c in query_node.column_list:
            deps = []

            for i in c.input_columns:
                col_name = column_name(i)
                rel_name = column_rel(i)

                if rel_name in from_tables:
                    table_columns = from_tables[rel_name]
                    deps.extend([d.wrap(c.expr) for d in table_columns.get(col_name, [])])

            col_name = column_name(c.output_column)
            while col_name in out_cols:
                col_name += ' '
            out_cols[col_name] = deps

    elif isinstance(query_node, SelectNode):

        for (i, select_clause) in enumerate(query_node.simple_select_clauses):
            deps = rewrite_statement(select_clause)
            if i == 0:
                out_cols = deps
            elif len(out_cols) != len(deps):
                max_d, min_d = (out_cols, deps) if len(out_cols) > len(deps) else (deps, out_cols)
                extra_deps = sum(min_d.values(), [])
                out_cols = OrderedDict([(k, v + extra_deps) for k, v in max_d.items()])
            else:
                names = list(out_cols.keys())
                for j, v in enumerate(deps.values()):
                    out_cols[names[j]].extend(v)

    elif isinstance(query_node, CTASNode):

        deps = rewrite_statement(query_node.select_clause)
        inputs = list(deps.values())
        for (i, c) in enumerate(query_node.columns):
            out_cols[column_name(c.name)] = inputs[i]

    elif isinstance(query_node, InsertNode):

        deps = rewrite_statement(query_node.select_clause)
        inputs = list(deps.values())
        for (i, c) in enumerate(query_node.columns):
            if i < len(inputs):  # check for default values
                out_cols[column_name(c.name)] = inputs[i]

        name = table_name(query_node.name)
        for ddl_col in db_catalog.table_columns.get(name, list()):
            if ddl_col not in out_cols.keys():
                out_cols[ddl_col] = list()

    elif isinstance(query_node, ExplainNode):
        rewrite_statement(query_node.stmt)

    return out_cols


def is_expr_trivial(expr):
    return re.match(r'^({COLREF}'
                    r'|{COLREF}::{IDENT}'
                    r'|{COLREF}::{IDENT}\(\s*\d+\s*\)'
                    r'|{COLREF}::{IDENT}\(\s*\d+\s*,\s*\d+\s*\)'
                    r')$'
                    .format(COLREF=COLREF, IDENT=IDENT),
                    expr.strip(), flags=re.I)


def is_expr_equal(expr):
    return re.match(r'^{COLREF}\s*=\s*{COLREF}$'.format(COLREF=COLREF),
                    expr.strip(), flags=re.I)


def add_pred(node):
    if not node.filter_predicate:
        node.filter_predicate = PredicateNode(node, 'AND')

    child = PredicateNode(node.filter_predicate)
    node.filter_predicate.elements.append(child)
    return child


def shift_pred_down(pred_type, node):
    if not node.filter_predicate:
        node.filter_predicate = PredicateNode(node, 'AND')

    child = PredicateNode(node.filter_predicate, pred_type)
    node.filter_predicate.elements.append(child)
    node.filter_predicate = child


def shift_pred_up(node):
    child = node.filter_predicate
    node.filter_predicate = node.filter_predicate.parent
    if not child.elements:
        node.filter_predicate.elements.remove(child)


def pushdown_predicate(p, from_tables, affected_tables=None):

    if p.formula not in ('AND', 'OR', 'NOT'):

        if len(p.input_columns) == 2 and is_expr_equal(p.formula):
            # table1.col = table2.col
            rel_name1 = column_rel(p.input_columns[0])
            col_name1 = column_name(p.input_columns[0])
            src_list1 = from_tables.get(rel_name1, {}).get(col_name1, [])

            rel_name2 = column_rel(p.input_columns[1])
            col_name2 = column_name(p.input_columns[1])
            src_list2 = from_tables.get(rel_name2, {}).get(col_name2, [])

            if len(src_list1) == 1 and len(src_list2) == 1:
                outer_tables = list()
                par = p.parent
                while par and isinstance(par, PredicateNode):
                    outer_tables.extend(par.outer_tables)
                    par = par.parent
                outer_tables = {table_name(t.alias or t.table_ref.rpartition('.')[2])
                                for t in outer_tables if isinstance(t, TableNode)}

                alt = src_list1[0].alternatives + src_list2[0].alternatives + [src_list1[0], src_list2[0]]
                if rel_name1 not in outer_tables:
                    src_list1[0].alternatives = [a for a in alt if a != src_list1[0]]
                if rel_name2 not in outer_tables:
                    src_list2[0].alternatives = [a for a in alt if a != src_list2[0]]

        if len(p.input_columns) == 1 \
                or len(p.input_columns) == 2 and 'semi-join' in p.input_columns:
            # table1.col = const_expr
            # table1.col in (select)

            is_semijoin = 'semi-join' in p.input_columns
            col = [c for c in p.input_columns if c != 'semi-join'][0]

            rel_name = column_rel(col)
            col_name = column_name(col)

            src_list = from_tables.get(rel_name, {}).get(col_name, [])
            for src in src_list:
                if any(not is_expr_trivial(e) for e in src.expr_path if e):
                    continue

                pushdown = add_pred(src.node)
                cast = ''.join([''.join(e.partition('::')[1:]) for e in src.expr_path])
                col = r'\b({t}.{c}|{c})\b'.format(t=rel_name, c=col_name)
                pushdown.formula = re.sub(col, src.name + cast, p.formula, flags=re.I)
                pushdown.semijoin = p.semijoin or is_semijoin

                src_list.extend([a for a in src.alternatives if a not in src_list])

        if len(p.input_columns) == 0 and affected_tables:
            # const_expr
            for node in affected_tables:
                pushdown = add_pred(node)
                pushdown.formula = p.formula

    elif p.formula == 'AND':
        for e in p.elements:
            pushdown_predicate(e, from_tables, affected_tables)

    elif p.formula == 'OR':
        real_inputs = list()
        for c in p.input_columns:
            real_inputs.extend(from_tables.get(column_rel(c), {}).get(column_name(c), []))

        if len({column_rel(i.name) for i in real_inputs}) != 1:
            return

        if any([c == 'semi-join' for c in p.input_columns]):
            return

        affected_tables = {src.node for src in real_inputs}
        list(map(partial(shift_pred_down, 'OR'), affected_tables))

        for e in p.elements:
            list(map(partial(shift_pred_down, 'AND'), affected_tables))
            pushdown_predicate(e, from_tables, affected_tables)
            list(map(shift_pred_up, affected_tables))

        list(map(shift_pred_up, affected_tables))


def fmt_predicate(p, semijoin=False):
    fmt_childer = partial(fmt_predicate, semijoin=semijoin)
    if p.formula in ('AND', 'OR'):
        elemets = list(filter(None, map(fmt_childer, p.elements)))
        sep = u' {} '.format(p.formula)
        if len(elemets) > 1:
            return '(' + sep.join(elemets) + ')'
        else:
            return sep.join(elemets)
    elif p.formula == 'NOT':
        return u'NOT ' + fmt_childer(p.elements[0])
    elif p.semijoin and semijoin or not p.semijoin and not semijoin:
        return p.formula
