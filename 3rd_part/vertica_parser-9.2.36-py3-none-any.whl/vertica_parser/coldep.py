#!/usr/bin/python
# -*- coding: utf-8 -*-

import io
import sys
import copy
import re

from vertica_parser import parser, db_catalog, parse_statement, print_node
from vertica_parser import RootNode, CTASNode, InsertNode, ViewNode
from vertica_parser import SelectNode, SimpleSelectNode, TableNode, JoinNode
from vertica_parser.analyzer import list_cte, list_from, list_predicates


def table_name(qualified_name):
    return qualified_name.lower()


def column_name(qualified_name):
    return qualified_name.rpartition('.')[2].strip('"').lower()


def column_rel(qualified_name):
    return qualified_name.rpartition('.')[0].strip('"').lower()


def is_identity(expr):
    return re.match('^([a-z_][a-z0-9_]*\.)?([a-z_][a-z0-9_]*)$', expr, re.I)


def and_predicates(predicate_node):
    if not predicate_node:
        return list()
    elif predicate_node.formula == 'AND':
        return [p for p in predicate_node.elements if not p.elements]
    elif predicate_node.formula and not predicate_node.elements:
        return [predicate_node]
    else:
        return list()


def joint_table_name(table_node):
    if isinstance(table_node, JoinNode):
        if table_node.join_type.lower() == 'right join':
            return joint_table_name(table_node.right_table)
        else:
            return joint_table_name(table_node.left_table)
    else:
        return (table_node.alias or table_node.table_ref.rpartition('.')[2]).lower()


class ColDep(object):
    def __init__(self):
        self.name = None
        self.deps = list()
        self.col_deps = list()
        self.tab_deps = list()


class EliminatedJoin(object):
    def __init__(self):
        self.node = None
        self.joint_table = None
        self.join_columns = list()


def dep_l2d(columns):
    return {c.name : c.deps for c in columns}


def primary_key(query_node, eliminated_joins):
    if isinstance(query_node, SelectNode):
        if len(query_node.simple_select_clauses) == 1:
            select_node = query_node.simple_select_clauses[0]
            return primary_key(select_node, eliminated_joins)

    elif isinstance(query_node, SimpleSelectNode):
        input2output = {}
        for c in query_node.column_list:
            if len(c.input_columns) == 1 and is_identity(c.expr):
                input2output[column_name(c.input_columns[0])] = c.output_column
            elif c.func and c.output_column != 'any':
                input2output[c.output_column] = c.output_column

        if query_node.is_distinct:
            return [c.output_column for c in query_node.column_list]

        elif query_node.groupby_list:

            groupby_column = list()
            groupby_number = list()

            for c in query_node.groupby_list:
                if re.match('^[1-9][0-9]*$', c):
                    groupby_number.append(query_node.column_list[int(c) - 1].output_column)
                elif is_identity(c) and column_name(c) in input2output:
                    groupby_column.append(input2output[column_name(c)])

            if len(groupby_column) == len(query_node.groupby_list):
                return groupby_column

            if len(groupby_number) == len(query_node.groupby_list):
                return groupby_number

        else:
            rownum_pk = list()
            for c in query_node.column_list:
                if c.func and c.func.func_name.lower() == 'public.row_number':
                    rownum_pk.extend([column_name(pc) for pc in c.func.partition_list])
                    rownum_pk.append(c.output_column)
                    break

            if rownum_pk and all([c in input2output for c in rownum_pk]):
                return [input2output[c] for c in rownum_pk]

            if len(query_node.from_list) == 1:
                subquery_pk = primary_key(query_node.from_list[0], eliminated_joins)

                for p in and_predicates(query_node.where_clause):
                    if re.match('^([a-z_][a-z0-9_]*\.)?([a-z_][a-z0-9_]*)\s*=\s*[0-9]+$', p.formula, re.I):
                        subquery_pk = [c for c in subquery_pk if c != column_name(p.input_columns[0])]

                if subquery_pk and all([c in input2output for c in subquery_pk]):
                    return [input2output[c] for c in subquery_pk]

        return list()

    elif isinstance(query_node, JoinNode):
        for i in range(2):
            join_type = query_node.join_type.lower()
            joint_pk = list()

            if 'right' in join_type or join_type in ('join', 'inner join', 'full outer join') and i == 1:
                core_table = query_node.right_table
                joint_table = joint_table_name(query_node.left_table)
                joint_pk = [joint_table + '.' + c for c in primary_key(query_node.left_table, eliminated_joins)]

            elif 'left' in join_type or join_type in ('join', 'inner join', 'full outer join') and i == 0:
                core_table = query_node.left_table
                joint_table = joint_table_name(query_node.right_table)
                joint_pk = [joint_table + '.' + c for c in primary_key(query_node.right_table, eliminated_joins)]

            join_columns = list()
            for p in and_predicates(query_node.join_predicate):
                if re.match('^[a-z0-9_\.]+\s*=\s*[a-z0-9_\.]+$', p.formula, re.I):
                    join_columns.extend([column_name(c) for c in p.input_columns if c in joint_pk])

            if joint_pk and len(join_columns) == len(joint_pk):

                if join_type not in ('join', 'inner join', 'full outer join'):
                    ej = EliminatedJoin()
                    ej.joint_table = joint_table
                    ej.join_columns = join_columns
                    ej.node = query_node
                    eliminated_joins.append(ej)
                    print ('elimination candidate: ' + joint_table + ' on ' + ','.join(join_columns))

                return primary_key(core_table, eliminated_joins)

    elif isinstance(query_node, TableNode):
        if query_node.table_ref:
            return db_catalog.table_pk.get(table_name(query_node.table_ref), list())
        else:
            return primary_key(query_node.select_clause, eliminated_joins)

    return list()


def analyze_joins(select_node):

    eliminated_joins = list()
    pk = primary_key(select_node, eliminated_joins)

    if isinstance(select_node.parent, SelectNode) and isinstance(select_node.parent.parent, CTASNode):
        db_catalog.table_pk[table_name(select_node.parent.parent.name)] = pk

    return eliminated_joins


def collect_column_dependencies(query_node):

    columns = list()

    if isinstance(query_node, SimpleSelectNode):

        cte_nodes = {table_name(cte.alias): cte.select_clause for cte in list_cte(query_node)}

        from_tables = dict()
        for table in list_from(query_node):
            alias = table_name(table.alias or table.table_ref.rpartition('.')[2])

            if table.select_clause:
                from_tables[alias] = dep_l2d(collect_column_dependencies(table.select_clause))

            elif table_name(table.table_ref) in cte_nodes:
                table.select_clause = cte_nodes[table_name(table.table_ref)]
                table.table_ref = None
                table.alias = alias
                from_tables[alias] = dep_l2d(collect_column_dependencies(table.select_clause))

            elif table_name(table.table_ref) in db_catalog.table_columns:
                from_tables[alias] = {c: [table_name(table.table_ref) + '.' + c]
                                      for c in db_catalog.table_columns[table_name(table.table_ref)]}

        transform_inputs = list()
        for alias in from_tables:
            transform_inputs.extend(from_tables[alias].get('any', list()))

        eliminated_joins = {ej.node: ej for ej in analyze_joins(query_node)}

        for c in query_node.column_list:
            cd = ColDep()
            cd.name = column_name(c.output_column)

            input_rel = [column_rel(i) for i in c.input_columns]

            predicate_inputs = list()
            for p in list_predicates(query_node):
                if p.parent not in eliminated_joins:
                    predicate_inputs.extend(p.input_columns)
                elif eliminated_joins[p.parent].joint_table in input_rel:
                    predicate_inputs.extend(p.input_columns)

            for i in c.input_columns + list(set(predicate_inputs)):
                col_name = column_name(i)
                rel_name = column_rel(i)

                if rel_name in from_tables:
                    cd.deps.extend(from_tables[rel_name][col_name])
                elif transform_inputs:
                    cd.deps.extend(transform_inputs)

            columns.append(cd)

    elif isinstance(query_node, SelectNode):

        for (i, select_clause) in enumerate(query_node.simple_select_clauses):
            deps = collect_column_dependencies(select_clause)

            for (j, d) in enumerate(deps):
                if i == 0:
                    cd = ColDep()
                    cd.name = d.name
                    columns.append(cd)
                columns[j].deps.extend(d.deps)

    elif isinstance(query_node, CTASNode):

        columns = collect_column_dependencies(query_node.select_clause)
        for (i, c) in enumerate(query_node.columns):
            columns[i].name = column_name(c.name)

    elif isinstance(query_node, InsertNode):

        columns = collect_column_dependencies(query_node.select_clause)
        for (i, c) in enumerate(query_node.columns):
            if i < len(columns):  # asume default values are not filled
                columns[i].name = column_name(c.name)

        name = table_name(query_node.name)
        for ddl_col in db_catalog.table_columns.get(name,list()):
            if ddl_col not in [insert_col.name for insert_col in columns]:
                cd = ColDep()
                cd.name = ddl_col
                columns.append(cd)

    elif isinstance(query_node, ViewNode):

        columns = collect_column_dependencies(query_node.select_clause)
        for (i, c) in enumerate(query_node.columns):
            columns[i].name = column_name(c.name)

    return columns


def collect_script_dependencies(statements):
    root = RootNode()
    parse_statement(parser.parse(statements), root)
    # print_node(root)

    table_columns = dict()
    for st in root.statements:

        if isinstance(st, SelectNode):
            c = st.simple_select_clauses[0].column_list[0]
            if c.output_column.lower() == 'swap_partitions_between_tables':
                m = re.search('\(([^,)]*),.*,([^,)]*)\)', c.expr, flags=re.U | re.M | re.I)
                t1 = table_name(m.group(1).strip(" \t\n'"))
                t2 = table_name(m.group(2).strip(" \t\n'"))
                if t1 in table_columns:
                    table_columns[t2] = table_columns[t1]
                elif t2 in table_columns:
                    table_columns[t1] = table_columns[t2]

        elif type(st) in (CTASNode, ViewNode, InsertNode):
            out_table = table_name(st.name)
            table_columns.setdefault(out_table, list())

            for c in collect_column_dependencies(st):

                known_col = [cd for cd in table_columns[out_table] if cd.name == c.name]
                if known_col:
                    cd = known_col[0]
                else:
                    cd = ColDep()
                    cd.name = c.name
                    table_columns[out_table].append(cd)

                for d in c.deps:
                    if column_rel(d) in table_columns and column_rel(d) != out_table:
                        cd.deps.extend(dep_l2d(table_columns[column_rel(d)])[column_name(d)])
                    else:
                        cd.deps.append(d)

                cd.deps = list(set(cd.deps))

            # for c in table_columns[out_table]:
            #     print(out_table + '.' + c.name + ':\t' + ','.join(c.deps))

    return table_columns


def run_dummy():
    db_catalog.table_columns = {
        'dds.l_item_user': ['item_id', 'user_id'],
        'dds.h_itemstatus': ['itemstatus_id', 'external_id'],
        'dds.l_item_itemstatus': ['item_id', 'itemstatus_id', 'actual_date'],
        'dds.s_item_lfiswaiting': ['item_id', 'lfiswaiting', 'actual_date'],
        'dds.l_item_category': ['item_id', 'category_id', 'actual_date'],
        'dma.calendar': ['event_date'],
        'dma.current_eventtypes': ['eventtype_id', 'viewtype', 'slug'],
        'dma.click_stream': ['item_id', 'event_date', 'user_id', 'weblog_id', 'cookie_id', 'eventtype_id', 'apptype_id', 'clientsideapp_id'],
    }
    db_catalog.table_pk = {
        'dma.click_stream': ['weblog_id'],
        'dma.current_eventtypes': ['eventtype_id'],
        'dma.calendar': ['event_date'],
        'dds.h_itemstatus': ['itemstatus_id'],
        'dds.l_item_user': ['item_id'],
    }

    statements = """
        create table dma.test as
        with t as (
            select *
            from (
                select *, row_number() over(partition by item_id order by actual_date desc) as rn
                from dds.l_item_itemstatus
            ) t
            where rn = 1
        )
        select iu.*
        from dds.l_item_user iu
        left join t on t.item_id = iu.item_id and t.rn = 1
        order by item_id
        segmented by hash(item_id) all nodes
        """

    file_columns = collect_script_dependencies(statements)
    for t in file_columns:
        for c in file_columns[t]:
            print(t + '.' + c.name + ':\t' + ','.join(c.deps))


def run_file(filepath, echo=True):

    with io.open(filepath, mode="r", encoding="utf-8") as ifile:
        content = ifile.read()
        statements = re.sub('dev_(DMA|TMP)\.', '\\1.', content, flags=re.I | re.U)
        statements = re.sub('v_temp_schema\.', '', statements, flags=re.I | re.U)

    ret = dict()

    file_columns = collect_script_dependencies(statements)
    for t in file_columns:
        if t.startswith('dma'):
            for c in file_columns[t]:
                print(t + '.' + c.name + ':\t' + ','.join(c.deps))
            ret = {t: file_columns[t]}

    return ret


def run_dir(dirpath):

    #parse meta
    import os
    for filename in os.listdir(dirpath):
        with io.open(dirpath + '/' + filename, mode="r", encoding="utf-8") as ifile:
            content = ifile.read()

        match = re.search("@datamart\s+([^\s]+)", content, re.U | re.I)
        if not match:
            continue
        datamart_name = match.group(1)

        datamart_pk = []
        for match in re.finditer('@key\s+([^\s]+)', content, re.UNICODE | re.IGNORECASE):
            datamart_pk.append(column_name(match.group(1)))

        db_catalog.table_pk[table_name(datamart_name)] = datamart_pk

    #run
    import logging

    db_table_columns = copy.deepcopy(db_catalog.table_columns)
    db_table_pk = copy.deepcopy(db_catalog.table_pk)

    table_columns = dict()

    for filename in os.listdir(dirpath):
        try:
            logging.info(filename)
            # sys.stdout = open(os.devnull, 'w')
            db_catalog.table_columns = copy.deepcopy(db_table_columns)
            db_catalog.table_pk = copy.deepcopy(db_table_pk)
            table_columns.update(run_file(dirpath + '/' + filename))
            # sys.stdout = sys.__stdout__
        except:
            # sys.stdout = sys.__stdout__
            logging.exception(filename + ' failed')

    #compute deps
    for t in table_columns:
        for c in table_columns[t]:
            c.col_deps = [d for d in c.deps if d.startswith('dma')]
            c.tab_deps = [column_rel(d) for d in c.deps if d.startswith('dma')]

    for i in range(20):
        table_columns_c = dict()
        table_columns_t = dict()

        for t in table_columns:
            table_columns_c.setdefault(t, list())
            table_columns_t.setdefault(t, list())

            for c in table_columns[t]:
                next_deps = set()
                for d in c.col_deps:
                    if column_rel(d) in table_columns and column_rel(d) != t:
                        cd = {c.name: c.col_deps for c in table_columns[column_rel(d)]}
                        for ic in cd[column_name(d)]:
                            next_deps.add(ic)
                table_columns_c[t].append(list(next_deps))

                next_deps = set()
                for d in c.tab_deps:
                    if d in table_columns and d != t:
                        next_deps |= {td for cd in table_columns[d] for td in cd.tab_deps}
                table_columns_t[t].append(list(next_deps))

        for t in table_columns:
            for (i, c) in enumerate(table_columns[t]):
                table_columns[t][i].col_deps.extend(table_columns_c[t][i])
                table_columns[t][i].col_deps = list(set(table_columns[t][i].col_deps))
                table_columns[t][i].tab_deps.extend(table_columns_t[t][i])
                table_columns[t][i].tab_deps = list(set(table_columns[t][i].tab_deps))

    # print deps
    plot_data = list()
    for t in table_columns:
        inputs = list()
        inputs_c = list()
        inputs_t = list()
        for c in table_columns[t]:
            inputs_c.extend([column_rel(i) for i in c.col_deps])
            inputs_t.extend([table_name(i) for i in c.tab_deps])
            inputs.extend([column_rel(i) for i in c.deps if i.startswith('dma')])

        inputs = [i for i in set(inputs) if i != t]
        waste_deps = list(set(inputs_t) - set(inputs_c))
        print(t + ':\t' + ','.join(inputs) + ' [' + ','.join(waste_deps) + ']')
        for i in inputs:
            plot_data.append([i, t])
            # print("['{}','{}',1],".format(i, t))

    n = dict()
    nodes = list()
    links = list()
    for d in plot_data:
        if d[0] not in n:
            n[d[0]] = len(n)
            nodes.append({'name': d[0]})
        if d[1] not in n:
            n[d[1]] = len(n)
            nodes.append({'name': d[1]})
        links.append({'source': n[d[0]], 'target': n[d[1]], 'value': 1})

    a = dict()
    for i in range(10):
        links_nocycle = list()
        for l in links:
            a.setdefault(l['source'], set()).add(l['target'])
            if l['source'] in a.get(l['target'], set()):
                print('CYCLE:', l, nodes[l['source']], nodes[l['target']])
            else:
                links_nocycle.append(l)

    import json
    print(json.dumps({'nodes': nodes, 'links': links_nocycle}))


if __name__ == '__main__':

    credits = {'host': 'avi-dwh01', 'port': 5433,
               'user': 'tableau', 'password': '****',
               'database': 'DWH', 'read_timeout': 3600}
    db_catalog.load(credits)

    if sys.argv[1].endswith('.sql'):
        run_file(sys.argv[1])
    else:
        run_dir(sys.argv[1][:-1] if sys.argv[1].endswith('/') else sys.argv[1])
